# Heading
# Tiêu đề h1 nè.
## Tiêu đề h2 này.
### Tiêu đè h3 to như này.
#### Và đây là h4.
##### Tiếp đó là h5.
###### h6 bé nhất.
Còn đây là text.

# Character Style
**Đây là chữ in đậm.**

_Đây là in nghiêng nha_.

**_Còn đây là vừa in đậm, vừa in nghiêng._**

`Đây là chữ cho trong hộp.`

~~Còn đây là chữ gạch ngang, như bị xiên qua thân ấy.~~

> Văn bản trích dẫn thì trông như này.

# List
+ sublist 01
+ sublist 02
1. Sublist 03
2. Sublist 04

# Link
Bài tập tuần này nè: [Link](https://mimpython.github.io/pythonSummerCourse/week-05-assignment/)

