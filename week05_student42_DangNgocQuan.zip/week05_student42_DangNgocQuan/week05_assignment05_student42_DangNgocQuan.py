from itertools import count

if __name__ == '__main__':
    '''a) Viết một chương trình chạy vô hạn sử dụng vòng lặp while.'''
    while 1:
        1
        
    '''b) Viết một chương trình chạy vô hạn sử dụng vòng lặp for và không dùng vòng lặp while.'''
    lst = [1]
    for num in lst:
        lst.append(num+1)
        
    '''c) Viết một chương trình chạy vô hạn sử dụng vòng lặp for mà đối tượng được duyệt 
    (sau từ khóa in) không phải là một list, tuple, set, hay dictionary.'''
    for i in count(1):
        print(i)
    