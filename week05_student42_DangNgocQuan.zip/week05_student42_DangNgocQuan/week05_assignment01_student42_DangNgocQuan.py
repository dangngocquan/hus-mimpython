'''
Responsitory: https://github.com/dangngocquan/MIMPythonWeek05

List of work done:
- Write commit 
- create tag for commit
- create new branch
- open new issue
- close issue
- pull

'''